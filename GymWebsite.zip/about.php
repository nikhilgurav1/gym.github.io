<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/about.css" type="text/css">

</head>
<body>
<h1>Way Join Us </h1>


<div>
  <a href="#" class="list-group-item-success">We have 10 year's of experiunce in gymnast. Best Envoirment For All.. </a><br><br>
  <a href="#" class="list-group-item-success">We Have Best Nutrition Support For Your Body Type..</a><br><br>
  <a href="#" class="list-group-item-success">We Recpect Your Privecy Thats Why We Give You Best Ladis Special Coach And Timing Too.</a><br><br>
  <a href="#" class="list-group-item-danger"> We Find is EvryOne Is Tomuch Intrested In Exersise But They Cannot Start Becouse of Timming. Here Is Flexible Timeming</a><br><br>
  <a href="#" class="list-group-item-warning">Bath Therepy</a><br><br>
  <a href="#" class="list-group-item-info">Suppliment Guidance</a><br><br>
  <a href="#" class="list-group-item-warning">Personol Guidance..</a><br><br>
  <a href="#" class="list-group-item-warning">Post and Pre Worl-out food</a><br><br>
  </div>

</body>
</html>